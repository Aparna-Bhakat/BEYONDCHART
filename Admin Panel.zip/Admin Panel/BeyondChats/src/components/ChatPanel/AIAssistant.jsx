// src/components/AIAssistant.jsx
import { useState } from "react";
import axios from "axios";

const AIAssistant = ({ aiMessages, setAiMessages }) => {
  const [userInput, setUserInput] = useState("");
  const [loading, setLoading] = useState(false);
  const API_KEY = VITE_OPENAI_API_KEY;

  const handleAIAsk = async () => {
    if (!userInput.trim()) return;

    setAiMessages((prev) => [...prev, { sender: "user", message: userInput }]);

    try {
      setLoading(true);

      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a helpful AI assistant for customer support." },
            ...aiMessages.map((m) => ({
              role: m.sender === "user" ? "user" : "assistant",
              content: m.message,
            })),
            { role: "user", content: userInput },
          ],
        },
        {
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            "Content-Type": "application/json",
          },
        }
      );

      const aiResponse = response.data.choices[0].message.content;
      setAiMessages((prev) => [...prev, { sender: "ai", message: aiResponse }]);
    } catch (error) {
      setAiMessages((prev) => [...prev, { sender: "ai", message: "Something went wrong. Try again." }]);
    } finally {
      setLoading(false);
      setUserInput("");
    }
  };

  return (
    <div className="bg-white border-r p-4 mt-auto flex flex-col shadow-md rounded-md w-full">
      <h2 className="text-xl font-semibold text-[#245970] mb-4 flex items-center gap-2">
        🤖 <span>AI Assistant</span>
      </h2>

      <div className="flex-1 space-y-3 text-sm overflow-y-auto mb-4 pr-1 custom-scrollbar">
        {aiMessages.map((msg, index) => (
          <div
            key={index}
            className={`max-w-[85%] p-3 rounded-lg shadow-sm  ${
              msg.sender === "user"
                ? "bg-gradient-to-l from-[#e0f7fa] to-[#b2ebf2] self-end text-right ml-auto"
                : "bg-[#f0f4ff] text-left"
            }`}
          >
            {msg.message}
          </div>
        ))}
        {loading && (
          <div className="text-xs text-gray-400 italic animate-pulse">
            Typing...
          </div>
        )}
      </div>

      <div className="flex gap-2 mt-auto">
        <input
          className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#245970] transition-all duration-200"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAIAsk()}
          placeholder="Ask something..."
        />
        <button
          onClick={handleAIAsk}
          className="bg-[#245970] hover:bg-[#1b4560] text-white px-4 py-2 text-sm rounded-md transition-all duration-200 hidden md:block"
        >
          Ask
        </button>
      </div>
    </div>
  );
};

export default AIAssistant;

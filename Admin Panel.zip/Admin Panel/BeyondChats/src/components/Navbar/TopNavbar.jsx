import { FaUserCircle } from "react-icons/fa";
import { motion } from "framer-motion";

const avatarUrl = null;

const TopNavbar = () => {
  return (
    <motion.header
  className="  fixed top-0 left-0 w-full h-16 bg-white shadow z-50 flex justify-between items-center px-4"

      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }} >
    
  
      <div className="text-2xl font-extrabold text-[#245970] ">
        BeyondChats
      </div>

     
    
        {avatarUrl ? (
          <motion.img
            src={avatarUrl}
            alt="User Avatar"
            className="w-10 h-10 rounded-full object-cover border-2 border-[#4f8ea9]"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          />
        ) : (
          <FaUserCircle className="w-10 h-10 text-gray-400" />
        )}


    
    </motion.header>
  );
};

export default TopNavbar;

import TopNavbar from "../Navbar/TopNavbar";
import Sidebar from "../Navbar/SideNavBar";
import HeroPanel from "../HeroPanel/HeroPanel";


const Homepage=()=>{
    return(
        <>
         <Sidebar/>
        <TopNavbar/> 
         <HeroPanel/>
         
</>
    )

}


export default Homepage
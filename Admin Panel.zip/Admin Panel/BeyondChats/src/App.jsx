import { createBrowserRouter, RouterProvider } from "react-router-dom";
import './App.css'
import Homepage from "./components/Homepage/Homepage";
import ChatDetailPage from "./components/ChatPanel/ChatDetailPage";


const  router =createBrowserRouter([
  {

  path:"/",
  element:<Homepage/>
  },
  {path:"/chat/:userName",
  element:<ChatDetailPage/>},

])

function App(){
  return(
      <div>
    
      <RouterProvider router={router}/>
     

    </div>
  )
}


export default App
